function calculateBMI() {
    const weight = document.getElementById("weight").value;
    const height = document.getElementById("height").value;
    const system = document.getElementById("system").value;
    let bmi;
  
    if (system === "metric") {
      bmi = weight / (height / 100) ** 2;
    } else {
      bmi = (weight / (height ** 2)) * 703;
    }
  
    document.getElementById("bmi").innerHTML = bmi.toFixed(2);
  
    let interpretation;
  
    if (bmi < 18.5) {
      interpretation = "A BMI of 0 - 18.5 indicates that you are at a under weight for your height.";
    } else if (bmi >= 18.5 && bmi <= 24.9) {
      interpretation = "A BMI of 18.5 - 25 indicates that you are at a healthy weight for your height. By maintaining a healthy weight, you lower your risk of developing serious health problems.";
    } else if (bmi >= 25 && bmi <= 29.9) {
      interpretation = "A BMI of >30 indicates that you are at a obese weight for your height.";
    } else {
      interpretation = "Obese";
    }
  
    document.getElementById("interpretation").innerHTML = interpretation;
  
    document.querySelector(".result").style.display = "block";
  }
  